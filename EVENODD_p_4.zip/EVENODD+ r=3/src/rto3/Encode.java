/**
 * @author Administrator
 * @date 2019/12/30 0030 19:30
 */
package rto3;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import static rto3.Protocol.*;

public class Encode {
    /**	对于阵列码需要添加参数p*/
//    public static final int m = Protocol.m;
//    public static final int k = Protocol.k;
//    public static final int DATA_NODES = k;
//    public static final int r = Protocol.r;
//    public static final int TOTAL_NODES = k+r;
//    public static final int BYTES_IN_INT = 4;

    public static void main(String [] arguments) throws IOException {
    	String filePath = "D:\\JAVAworkspace\\3.pdf";
        final File inputFile = new File(filePath);
        if (!inputFile.exists()) {
            System.out.println("Cannot read input file: " + inputFile);
            return;
        }

        // Get the size of the input file.  (Files bigger that
        // Integer.MAX_VALUE will fail here!)
        int fileSize = (int) inputFile.length();
        // Figure out how big each shard will be.  The total size stored
        // will be the file size (8 bytes) plus the file.
        int storedSize = fileSize ;		   
        while(!(storedSize % (m - 1) == 0) || !(storedSize % DATA_NODES == 0)){
        	storedSize++;
        }
        int nodesize = storedSize / DATA_NODES;
        int blocksize= nodesize/(m-1);
        
        System.out.println("filesize = " + fileSize);
        System.out.println("nodesize = " + nodesize);
        System.out.println("blocksize = " + blocksize);
        
        
        // Create a buffer holding the file size, followed by the contents of the file.
        int bufferSize = nodesize * DATA_NODES;
        System.out.println("bufferSize = " + bufferSize);
        byte[] allBytes = new byte[bufferSize];
        ByteBuffer.wrap(allBytes).putInt(fileSize);
        InputStream in = new FileInputStream(inputFile);
        int bytesRead = in.read(allBytes, 0, fileSize);  //从输入流中读取最多fileSize-BYTES_IN_INT个字节到字节数组中(从数组的BYTES_IN_INT位置开始存储字节)
        //System.out.println("fileSize = " + fileSize);
        //System.out.println("bytesRead = " + bytesRead);
        if (bytesRead != fileSize){
            throw new IOException("not enough bytes read");
        }
        in.close();
        System.out.println("allByte size = " + allBytes.length);
    	 
        
        //Make the buffers to hold the shards.
        byte[][] shards = new byte [TOTAL_NODES][nodesize];	
        for (int i = 0; i < DATA_NODES; i++) {
            System.arraycopy(allBytes, i * nodesize, shards[i], 0, nodesize);
        }
        
        //检验一个填充的矩阵是否正确
        /*
        for(int j=0;j<m-1;j++){
        	for(int i=0; i<k+r; i++){
        		System.out.print(shards[i][3+blocksize*j]+" ");
            }
        	System.out.println();
        }*/

        byte[] f1 = new byte[blocksize];
        byte[] f2 = new byte[blocksize];
        byte[] f3 = new byte[blocksize];

        long startTime = System.nanoTime();
        evenodd eo = evenodd.create();
        if(r==2)
        {eo.encodeParity0(f1,shards, nodesize, blocksize);}
        if(r==3)
        {eo.encodeParity(f1,f2,shards, nodesize, blocksize);}
        if(r==4)
        {eo.encodeParity1(f1,f2,f3,shards, nodesize, blocksize);}
        long endTime = System.nanoTime();
        
        System.out.println();
        
       //检验校验列是否编码是否正确
        
        for(int j=0;j<m-1;j++){
        	for(int i=0; i<k+r; i++){
        		System.out.print(shards[i][3+blocksize*j]+" ");
            }
        	System.out.println();
        }
        
       
        float Time= (float)(endTime - startTime)/1000000000;
		float Length=(float)fileSize/1024/1024;
		System.out.println("编码时间：" +Time + "s");
		System.out.println("编码速率：" + (float)Length/Time + "Mb/s");
        for (int i = 0; i < blocksize; i++) {
            f3[i] = (byte) (f1[i]^f2[i]);
        }

        // Write out the resulting files.
        for (int i = 0; i < TOTAL_NODES; i++) {
            File outputFile = new File(
                    inputFile.getParentFile(),
                    inputFile.getName() + "." + i);
            OutputStream out = new FileOutputStream(outputFile);
            out.write(shards[i]);
            out.close();
            System.out.println("wrote " + outputFile);
        }

        File outputFile = new File(
                inputFile.getParentFile(),
                inputFile.getName() + "." + 111);
        OutputStream out = new FileOutputStream(outputFile);
        out.write(f1);
        out.close();
    }
}
