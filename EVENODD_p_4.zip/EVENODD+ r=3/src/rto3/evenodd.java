/**
 * @author Administrator
 * @date 2019/12/30 0030 19:33
 */
package rto3;
public class evenodd extends Evenodd3func{

    public final int k = Protocol.k;
    public final int m = Protocol.m;
    public final int r = Protocol.r;

    /**
     * Creates a EVENODD codec with the default coding loop.
     * */
    public static evenodd create() {
        return new evenodd();
    }

    public evenodd() {

    }

    public void encodeParity0(byte[] f1, byte[][] shards, int shardsize, int blocksize) {
        int m = shards.length;//列
        int l = shards[0].length;//行
        byte[][] temp = new byte[l][m];
        transposed(temp, shards);
        /*
        for (int i = 0; i < blocksize; i++) {
            f1[i] = temp[1*blocksize+i][r];
        }*/
        getFactor0(f1, temp, blocksize);
        horiXOR(temp, shardsize);
        diagXOR0(temp, shardsize, blocksize);
        transposed(shards,temp);
    }
    
    public void encodeParity(byte[] f1, byte[] f2, byte[][] shards, int shardsize, int blocksize) {
        int m = shards.length;//列
        int l = shards[0].length;//行
        byte[][] temp = new byte[l][m];
        transposed(temp, shards);
        /*
        for (int i = 0; i < blocksize; i++) {
            f1[i] = temp[1*blocksize+i][r];
        }*/
        getFactor1(f1,f2, temp, blocksize);
        horiXOR(temp, shardsize);
        diagXOR(temp, shardsize, blocksize);
        transposed(shards,temp);
    }

    public void encodeParity1(byte[] f1, byte[] f2,byte[] f3, byte[][] shards, int shardsize, int blocksize) {
        int m = shards.length;//列
        int l = shards[0].length;//行
        byte[][] temp = new byte[l][m];
        transposed(temp, shards);
        /*
        for (int i = 0; i < blocksize; i++) {
            f1[i] = temp[1*blocksize+i][r];
        }*/
        getFactor2(f1,f2,f3, temp, blocksize);
        horiXOR(temp, shardsize);
        diagXOR1(temp, shardsize, blocksize);
        transposed(shards,temp);
    }

    public void decodeMissing(byte[] f1, byte[][] shards, boolean[] shardPresent, int shardSize, int blocksize){

        int m = shards.length;//列
        int l = shards[0].length;//行
        byte[][] temp = new byte[l][m];
        transposed(temp, shards);
        int[] error = new int[2];

        // Quick check: are all of the shards present?  If so, there's
        // nothing to do.
        int numberPresent = 0;
        int count = 0;
        for (int i = 0; i < k; i++) {
            if (shardPresent[i]) {
                numberPresent += 1;
            }else{
                error[count++]=i;
//                System.out.println("*********error = " + i + "************");
            }
        }
        if (numberPresent == k) {
            // Cool.  All of the shards data data.  We don't
            // need to do anything.
            return;
        }
        // More complete sanity check
        if (numberPresent < k-2) {
            throw new IllegalArgumentException("Not enough shards present");
        }

        decode(f1, temp,shardSize,blocksize,error[0],error[1]);
        transposed(shards, temp);
    }
}
