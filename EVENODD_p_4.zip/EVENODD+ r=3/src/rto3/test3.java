package rto3;
import java.io.IOException;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Optional;

import rto3.Evenodd3func;
import static rto3.Protocol.*;

public class test3 {
	 static byte slope_1=(byte)getMod(m-1-e1,m);
	 static byte slope_2=(byte)getMod(m-1-2*e1,m);
	 static byte slope_3=(byte)getMod(m-1-3*e1,m);
	 
	 public static int gcd(int a, int b) {
	    	int temp=0;
	    	do {
	    	   if(b==0) {
	    		  return a;
	    	   }else {
	    		temp=a%b;
	    		a=b;
	    		b=temp;
	    	   }
	    	}while(b>0);
	    	return a;
	 }
	 
	 public static int getMod(int a, int b) {
	        if(a >= 0) {
	            return a % b;
	        }else{
	            while(a < 0){
	                a += b;
	            }
	            return a % b;
	        }
	 }
	 
	 public static int invert(int a, int p) {
		 int b=0;
		 if(gcd(a,p)==1) {
			 for (int k=1;k<10000;k++) {
				 if((p*(k-1)+1)/a<p && getMod((p*(k-1)+1),a)==0){
					 b=(p*(k-1)+1)/a;
					break;
				 }
			 }
		 }
		 return b;
	 }
	 
	 public static int gcdlow(int a, int b) {
	    	return b==0? a:gcdlow(b,a%b);
	 }
	 
	 public static void Spart_4(byte[][] S) throws IOException{
	    	HashSet<Byte> U=new HashSet<Byte>();
	    	HashSet<Byte> U_1=new HashSet<Byte>();
	    	for(byte i=0;i<m-1;i++) {
	    		U.add(i);
	    	}
	    	
	    	byte i2=0;
	    	byte ord=0;
	    	if (e1==0) {
	    	   i2=0;
	    	}else {
	    	   i2=(byte)getMod(m-1-2*e1,m);
	    	}
	    	
	    	for(int i=1;i<m;i++) {
	    	   if ((byte)getMod((int)Math.pow(2, 0)-1,m)==(byte)getMod((int)Math.pow(2, i)-1,m)) {
	    		  ord=(byte)i;
	    		  break;
	    	   }
	    	}
	    	
	    	HashSet<Byte> BS_0=new HashSet<Byte>();
	    	HashSet<Byte> BS_1=new HashSet<Byte>();
	    	HashSet<Byte> BS_2=new HashSet<Byte>();
	    	HashSet<Byte> BS_3=new HashSet<Byte>();
	    	
	    	/*
	    	Integer LS=(int) Math.floor(((float)(m-1)/4));
	    	Integer HS=(int) Math.ceil(((float)(m-1)/4));
            System.out.println(HS+"***HS");
	    	
	    	byte slope_1=(byte)getMod(m-1-e1,m);
	    	byte slope_2=(byte)getMod(m-1-2*e1,m);
	    	byte slope_3=(byte)getMod(m-1-3*e1,m);
	    	*/
	    	
	    while(BS_2.size()<HS) {
	    	for(int i=0;i<ord;i++) {
	    		if((byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m)==slope_2) {
	    			BS_0.add(slope_2);
	    		}else{
	    			  if ((byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m)!=slope_2 && (byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m)!=slope_2){
	    				  BS_2.add((byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m));
	    				  if(BS_2.size()==HS){
	    					 U_1.clear();
	    					 U_1=remove(U,BS_2);
	    					 if((i<ord-1) && BS_0.size()<LS && U_1.contains((byte)getMod((i2+1)*(int)Math.pow(2, i)*invert(2,m),m))) {
	    						BS_0.add((byte)getMod((i2+1)*(int)Math.pow(2, i)*invert(2,m),m));
	    						break;
	    					 }
	    				     break;
	    				  }
	    		      }	
	    		}
	    	}
	       U_1.clear();
	       U_1=remove(U,BS_0,BS_2);
	       i2=MIN_SET(U_1);
	    }
	    
	    System.out.println("2======");
	    BS_2.stream().forEach(System.out::println);
	    
	    
	    U_1.clear();
	    HashSet<Byte> BS_0_break=new HashSet<Byte>();
	    while(BS_0.size()<LS) {
	    	BS_0_break.addAll(BS_0);
	    	if (BS_0_break.size()==0) {
	    	    U_1=remove(U,BS_2);
	    		BS_0_break.add(MIN_SET(U_1));
	    	}
	    	U_1.clear();
	    	for (Byte i_0 : BS_0_break) {
				for (Byte i_2_ : BS_2) {
					byte i_2=(byte)getMod(i_2_+2*e1,m);
					byte i_1=(byte)getMod((i_0+i_2)*invert(2,m),m);
					U_1=remove(U,BS_0,BS_2);
					if(i_1==(byte)getMod(e1-1,m)){
							if (m<11) {
								if (BS_0.size()<LS && U_1.contains(slope_1))
									BS_0.add(slope_1);
							}else{
						    	if (BS_0.size()<LS && U_1.contains(slope_1) && i_1!=(byte)getMod(-2-i_2,m) && i_1!=(byte)getMod(3*i_2+2,m))
						    		BS_0.add(slope_1);
						    }
					}else {
							if (m<11) {
								if (BS_0.size()<LS && U_1.contains((byte)getMod(i_1-e1,m)))
									BS_0.add((byte)getMod(i_1-e1,m));
							}else{
								if (BS_0.size()<LS && U_1.contains((byte)getMod(i_1-e1,m)) && i_1!=(byte)getMod(-2-i_2,m) && i_1!=(byte)getMod(3*i_2+2,m))
									BS_0.add((byte)getMod(i_1-e1,m));
							}
					}
					U_1.clear();
				}
			}
	    	BS_0_break.clear();
	    	if (BS_0.size()==LS) {
	    		break;
	    	}
	     }
	    System.out.println("0======");
	    BS_0.stream().forEach(System.out::println);
	    
	    //填满BS_1
	    U_1.clear();
	    U_1=remove(U,BS_0,BS_2);
	    if (e1!=0) {
	    	if(U_1.contains(slope_1)) 
	    	   BS_1.add(slope_1);
	    	BS_3.add(slope_3);
	    }
	    
	    //System.out.println(slope_1);
	    System.out.println("1======");
	    BS_1.stream().forEach(System.out::println);
	    System.out.println("3======");
	    BS_3.stream().forEach(System.out::println);
	    
	    U_1.clear();
	    while(BS_1.size()<LS) {
	    	for (Byte i_0 : BS_0) {
				for (Byte i_2_ : BS_2) {
					byte i_2=(byte)getMod(i_2_+2*e1,m);
					byte i_3=(byte)getMod((3*i_2-i_0)*invert(2,m),m);
					System.out.print(i_3+"*");
					U_1=remove(U,BS_0,BS_2,BS_1,BS_3);
					  if (m<=11) {
						    if (BS_1.size()<LS && U_1.contains((byte)getMod(i_3-3*e1,m)))
							    BS_1.add((byte)getMod(i_3-3*e1,m));
					  }else{
						    if (BS_1.size()<LS && U_1.contains((byte)getMod(i_3-3*e1,m)) && i_3!=(byte)getMod((i_0-1)*invert(2,m),m) && i_3!=(byte)getMod((2*i_0-1)*invert(3,m),m) && i_3!=(byte)getMod((i_2-1)*invert(2,m),m))
						       {
						    	BS_1.add((byte)getMod(i_3-3*e1,m));
						        System.out.println(i_3+"++");
						       }
					  }
					U_1.clear();
			    }
	    	}
	    	if (BS_1.size()<LS) {
	    	   U_1.clear();
	  	       U_1=remove(U,BS_0,BS_2,BS_3,BS_1);
	  	       BS_1.add(MIN_SET(U_1));
	    	}
	     }
	    System.out.println("1======");
	    BS_1.stream().forEach(System.out::println);
	    
	    
	    //剩下BS_3
	    BS_3.clear();;
	    BS_3=remove(U,BS_0,BS_1,BS_2);
	      
	      /*
	      HashSet<Byte> BSdeal_0=new HashSet<Byte>();
	  	  HashSet<Byte> BSdeal_1=new HashSet<Byte>();
	  	  HashSet<Byte> BSdeal_2=new HashSet<Byte>();
	  	  HashSet<Byte> BSdeal_3=new HashSet<Byte>();
	  	  
	  	  BSdeal_0.addAll(BS_0);
	      for (Byte n1 : BS_1) {
			if (n1!=slope_1) {
				BSdeal_1.add((byte)getMod(n1+e1,m));
			}else {
				BSdeal_1.add((byte)getMod(e1-1,m));
			}
		  }
	      for (Byte n2 : BS_2) {
	  		if (n2!=slope_2) {
	  			BSdeal_2.add((byte)getMod(n2+2*e1,m));
	  		}else {
	  			BSdeal_2.add((byte)getMod(2*e1-1,m));
	  		}
	  	  }
	      
	      for (Byte n3 : BS_3) {
		  		if (n3!=slope_3) {
		  			BSdeal_3.add((byte)getMod(n3+3*e1,m));
		  		}else {
		  			BSdeal_3.add((byte)getMod(3*e1-1,m));
		  		}
		  }*/
	      OtoByte(BS_0,S,(byte) 0);
	      OtoByte(BS_1,S,(byte) 1);
	      OtoByte(BS_2,S,(byte) 2);
	      OtoByte(BS_3,S,(byte) 3);
	      
	      /*
	      OtoByte(BSdeal_0,Sdeal,(byte) 0);
	      OtoByte(BSdeal_1,Sdeal,(byte) 1);
	      OtoByte(BSdeal_2,Sdeal,(byte) 2);
	      OtoByte(BSdeal_3,Sdeal,(byte) 3);
		  */
	    }
	    
	    
	    public static void OtoByte(HashSet<Byte> BS,byte[][] S,byte mark) {
	    	int i=0;
	    	for (Byte n:BS) {
	  		  S[mark][i]=n;
	  		  i++;  
	  	    }
	    }
	    
	    public static void dealS(byte[][] S,byte[][] S_deal) {
	        for (int i = 0; i <LS; i++) {
	        	 S_deal[0][i]=S[0][i];
	    		 if(S[1][i]!=slope_1) {
	    			S_deal[1][i]=(byte)getMod(S[1][i]+e1,m);
	    		 }else {
	    			S_deal[1][i]=(byte)getMod(e1-1,m); 
	    		 }
			}
	        
	        for (int i = 0; i <HS; i++) {
	    		 if(S[2][i]!=slope_2) {
	    			S_deal[2][i]=(byte)getMod(S[2][i]+2*e1,m);
	    		 }else {
	    			S_deal[2][i]=(byte)getMod(2*e1-1,m); 
	    		 }
	    		 if(r==4) {
	    			 if(S[3][i]!=slope_3) {
	    				 S_deal[3][i]=(byte)getMod(S[3][i]+3*e1,m);
	    			 }else {
	    				 S_deal[3][i]=(byte)getMod(3*e1-1,m); 
	    			 }
	    		 }
			 }
	    }
	    
	    public static byte MIN_SET(HashSet<Byte> A) {
	    	Optional<Byte> optional=A.stream().min(new Comparator<Byte>(){
	        	@Override
	        	public int compare(Byte o1,Byte o2) {
	        		return o1-o2;
	        	    //return o2-o1;//max	
	        	}
	        });
	        byte i1= optional.get();
	    	return i1;
	   	}
	    
	    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A) {
	    	HashSet<Byte> U_1=new HashSet();
	    	U_1.addAll(U);
	    	U_1.removeAll(A);
	    	return U_1;
	   	}
	    
	    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A,HashSet<Byte> B) {
	    	HashSet<Byte> U_1=new HashSet();
	    	U_1.addAll(U);
	    	U_1.removeAll(A);
	        U_1.removeAll(B);
	    	return U_1;
	   	}
	    
	    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A,HashSet<Byte> B,HashSet<Byte> C) {
	    	HashSet<Byte> U_1=new HashSet();
	    	U_1.addAll(U);
	    	U_1.removeAll(A);
	        U_1.removeAll(B);
	        U_1.removeAll(C);
	    	return U_1;
	   	}
	    
	    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A,HashSet<Byte> B,HashSet<Byte> C,HashSet<Byte> D) {
	    	HashSet<Byte> U_1=new HashSet();
	    	U_1.addAll(U);
	    	U_1.removeAll(A);
	        U_1.removeAll(B);
	        U_1.removeAll(C);
	        U_1.removeAll(D);
	    	return U_1;
	   	}
	 
	    
	 public static void main(String[] args) throws IOException {
		System.out.println(gcd(2,18));
		System.out.println(gcdlow(3,4));
		System.out.println(invert(2,19));
		
		int e1=1;
		Evenodd3func F1=new Evenodd3func();
        int bandwidth=0;
        Integer LS=(int) Math.floor(((float)(m-1)/r));
    	Integer HS=(int) Math.ceil(((float)(m-1)/r));
    	byte[][] S =new byte[r][];
        S[0]=new byte[LS];
        S[1]=new byte[LS];
        S[2]=new byte[HS];
        if (r==4) {
        	S[3]=new byte[HS];
        }
      
        byte[][] Sdeal =new byte[r][];
        Sdeal[0]=new byte[LS];
        Sdeal[1]=new byte[LS];
        Sdeal[2]=new byte[HS];
        if (r==4) {
        	Sdeal[3]=new byte[HS];
        }
        
        if(r==3) 
          F1.Spart_3(S);
          dealS(S,Sdeal);
        if(r==4) { 
          Spart_4(S);
          dealS(S,Sdeal);
        }
        
        for(int i=0;i<S.length;i++) {
        	for(int j=0;j<S[i].length;j++) {
        		System.out.print(S[i][j]+" ");
        	}
        	System.out.println();
        }
        
        System.out.println();
        for(int i=0;i<Sdeal.length;i++) {
        	for(int j=0;j<Sdeal[i].length;j++) {
        		System.out.print(Sdeal[i][j]+" ");
        	}
        	System.out.println();
        }
	}
}

	