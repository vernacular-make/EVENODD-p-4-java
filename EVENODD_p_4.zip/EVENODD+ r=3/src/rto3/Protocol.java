package rto3;
/**
 * 
 * 
 * Protocol
 * 创建人:yaolan 
 * 时间：2020年4月8日-下午6:09:42 
 * @version 1.0.0
 *
 */
/*编码
 *1、p=11 1.mpv(1885kb) 
 *r=2  0.13s  13.2433Mb/s
 *r=3  0.155s 11.8404Mb/s
 *r=4  0.23s  7.9749Mb/s
 * 
 */
public class Protocol {
    public static final int m =17;//11;//19;//7;                      //p
    public static final int k =17;//11;//19;//7;                      //k
    public static final int r = 4;//3;                  //r=3 1.mpv
    public static final int e1= 2;
    public static final int DATA_NODES = k;
    public static final int TOTAL_NODES = k+r;
    public static final int NODE_NUM = k + r;
    public static final int BLOCK_SIZE = 1024 * 64;
    public static final int STRIPE_SIZE = BLOCK_SIZE * (m-1)*(k+3);	//CHUNK_SIZE = STRIPE_SIZE
    public static final int UPDATE_NODE_NUM = 2;
    public static final int MAX_TOLERANCE = 1;
    public static final int BYTES_IN_INT = 4;
    
    public static final int RACK_NUM = NODE_NUM;
    
    public static final Integer LS=(int) Math.floor(((float)(m-1)/r));
    public static final Integer HS=(int) Math.ceil(((float)(m-1)/r));
    
}
