package rto3;
import static rto3.Protocol.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.security.MessageDigest;

/**
 * Command-line program that decodes a file using Reed-Solomon 4+2.
 *
 * The file name given should be the name of the file to decode, say
 * "foo.txt".  This program will expected to find "foo.txt.0" through
 * "foo.txt.5", with at most two missing.  It will then write
 * "foo.txt.decoded".
 */
public class Repair {
    /**	对于阵列码需要添加参数p*/
    // @SuppressWarnings("ResultOfMethodCallIgnored")
    public static void main(String [] arguments) throws IOException {
//         for (int error=0;error<k;error++) {                  //ctrl+shift+c
//         int e1=error;
        	    /*读取非擦除列元素矩阵*/
                String filePath = "D:\\JAVAworkspace\\3.pdf";
                final File originalFile = new File(filePath);
                if (!originalFile.exists()) {
                    System.out.println("Cannot read input file: " + originalFile);
                    return;
                }
                int fileSize = (int) originalFile.length();
                System.out.println("FileSize : " + fileSize);

                // Read in any of the shards that are present.
                // (There should be checking here to make sure the input
                // shards are the same size, but there isn't.)
                final byte [] [] shards = new byte [TOTAL_NODES] [];
                final boolean [] shardPresent = new boolean [TOTAL_NODES];
                int shardSize = 0;
                int shardCount = 0;
                int blocksize = 0;
                for (int i = 0; i < TOTAL_NODES; i++) {
                    if(i == e1){
                        continue;
                    }
                    File shardFile = new File(
                            originalFile.getParentFile(),
                            originalFile.getName() + "." + i);
                    if (shardFile.exists()) {
                        shardSize = (int) shardFile.length();
                        blocksize = shardSize / (m - 1);
                        shards[i] = new byte [shardSize];
//                      System.out.println("shardSize : " + shardSize);
                        shardPresent[i] = true;
                        shardCount += 1;
                        InputStream in = new FileInputStream(shardFile);
                        in.read(shards[i], 0, shardSize);
                        in.close();
                    }
                }
                
              
                // We need at least DATA_NODES to be able to reconstruct the file.
                if (shardCount < DATA_NODES) {
                    System.out.println("Not enough shards present");
                    return;
                }

                // Make empty buffers for the missing shards.
                for (int i = 0; i < TOTAL_NODES; i++) {
                    if (!shardPresent[i]) {
                        shards[i] = new byte [shardSize];
                    }
                }
                
                /* 检测读取是否正确*/
                /*
                for(int j=0;j<m-1;j++){
                    for(int i=0; i<k+r; i++){
                  		System.out.print(shards[i][3+blocksize*j]+" ");
                    }
                    System.out.println();
                }
                for(int j=0;j<m-1;j++){
                    for(int i=0; i<k+r; i++){
                  		System.out.print(shards[i][1+blocksize*j]+" ");
                    }
                    System.out.println();
                }*/
                
                
                
                //byte[][] S= {{4},{5},{2,0},{1,3}};    //m=7 r=4
                //byte[][] S_1= {{4},{0},{4,2},{4,2}};
                
                //byte[][] S= {{8,3},{9,0},{6,2,5},{1,4,7}};    //m=11 r=4
                //byte[][] S_1= {{8,3},{0,1},{8,4,7},{4,7,2}};
                
                //byte[][] S= {{9,0,8},{6,2,5},{1,3,4,7}};    //m=11 r=3
                //byte[][] S_1= {{9,0,8},{7,3,6},{3,5,6,9}};
               
                /*
                byte[][] S= {                                 //m=19 r=3
                		{17,9,16,3,6,12},
                		{14,10,2,5,11,4},
                		{0,1,7,8,13,15},
                };
                byte[][] S_1= {                                 
                		{17,9,16,3,6,12},
                		{15,11,3,6,12,5},
                		{2,3,9,10,15,17},
                };*/
                /*
                byte[][] S= {                                 //m=19 r=4
                		{16,6,15,13},
                		{17,7,9,0},
                		{14,10,2,5,11},
                		{1,3,4,8,12}
                };
                byte[][] S_1= {                                 
                		{16,6,15,13},
                		{0,8,10,1},
                		{16,12,4,7,13},
                		{4,6,7,11,15}
                };*/
                
                /*
                byte[][] S= {                                 //m=31 r=4
                		{28,27,25,21,29,2,6},
                		{19,17,12,24,4,23,9},
                		{26,22,14,0,1,3,7,15},
                		{5,8,10,11,13,16,18,20}
                };
                byte[][] S_1= {                                 
                		{28,27,25,21,29,2,6},
                		{20,18,13,25,5,24,10},
                		{28,24,16,2,3,5,9,17},
                		{8,11,13,14,16,19,21,23}
                };*/
                
                /*
                byte[][] S= {                                 //m=31 r=3
                		{29,11,28,23,4,8,16,6,12,10},
                		{26,22,14,0,1,3,7,15,2,5},
                		{9,13,17,18,19,20,21,24,25,27},
                };
                byte[][] S_1= {                                 
                		{29,11,28,23,4,8,16,6,12,10},
                		{27,23,15,1,2,4,8,16,3,6},
                		{11,15,19,20,21,22,23,26,27,29},
                };*/
                
                
                Evenodd3func F1=new Evenodd3func();
                int bandwidth=0;
            	byte[][] S =new byte[r][];
                S[0]=new byte[LS];
                S[1]=new byte[LS];
                S[2]=new byte[HS];
                if (r==4) {
                	S[3]=new byte[HS];
                }
              
                byte[][] Sdeal =new byte[r][];
                Sdeal[0]=new byte[LS];
                Sdeal[1]=new byte[LS];
                Sdeal[2]=new byte[HS];
                if (r==4) {
                	Sdeal[3]=new byte[HS];
                }
                
                if(r==3) { 
                   F1.Spart_3(S);
                   F1.dealS(S,Sdeal);
                }
                if(r==4) { 
                   F1.Spart_4(S);
                   F1.dealS(S,Sdeal);
                }
                
                for(int i=0;i<S.length;i++) {
                	for(int j=0;j<S[i].length;j++) {
                		System.out.print(S[i][j]+" ");
                	}
                	System.out.println();
                }
                for(int i=0;i<Sdeal.length;i++) {
                	for(int j=0;j<Sdeal[i].length;j++) {
                		System.out.print(Sdeal[i][j]+" ");
                	}
                	System.out.println();
                }
                
                
                long startTime = System.nanoTime();
                if(r==3)
                	bandwidth=F1.repair_3(shards, shardSize, blocksize, e1, Sdeal,S);
                if(r==4) 
                    bandwidth=F1.repair_4(shards, shardSize, blocksize, e1, Sdeal,S);
                long endTime = System.nanoTime();
                
                float Time= (float)(endTime - startTime)/1000000000;
        		float Length=(float)shardSize/1024/1024;
        		System.out.println("修复时间：" +Time + "s");
        		System.out.println("修复速率：" + (float)Length/Time + "Mb/s");
                
                System.out.println(bandwidth);
                for(int j=0;j<m-1;j++){
                    for(int i=0; i<k+r; i++){
                  		System.out.print(shards[i][3+blocksize*j]+" ");
                    }
                    System.out.println();
                }
                
//                // Use EVENODD+ to fill in the missing shards
//                byte[] f1 = new byte[blocksize];
//
//                evenodd eo = evenodd.create();
//                eo.decodeMissing(f1, shards, shardPresent, shardSize, blocksize);
//
//                // Combine the data shards into one buffer for convenience.
//                // (This is not efficient, but it is convenient.)
//                byte [] allBytes = new byte [shardSize*DATA_NODES];
//                for (int i = 0; i < DATA_NODES; i++) {
//                    System.arraycopy(shards[i], 0, allBytes, shardSize * i, shardSize);
//                }
////        System.out.println("allByte size = " + allBytes.length);
//                // Extract the file length
//                int fileSize = ByteBuffer.wrap(allBytes).getInt();
////        System.out.println("file size = " + fileSize);
//
//                // Write the decoded file
//                File decodedFile = new File(originalFile.getParentFile(), originalFile.getName() + ".decoded");
//                OutputStream out = new FileOutputStream(decodedFile);
//                out.write(allBytes, BYTES_IN_INT, fileSize);
//                System.out.println("Wrote " + decodedFile);
//
//                File outputFile = new File(
//                        originalFile.getParentFile(),
//                        originalFile.getName() + "." + 222);
//                OutputStream out2 = new FileOutputStream(outputFile);
//                out2.write(f1);
//                out2.close();
//
//
//                // 读取原始文件
//                String path1 = "F:\\test\\text\\1.jpg";
//                String path2 = "F:\\test\\text\\1.jpg.decoded";
//
//                String hash_path1 = null;
//                String hash_path2 = null;
//                try {
//                    hash_path1 = getHash(path1, "MD5");
//                    hash_path2 = getHash(path2, "MD5");
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
////        System.out.println("path1 md5:" + hash_path1);
////        System.out.println("path2 md5:" + hash_path2);
//                if (hash_path1.endsWith(hash_path2)) {
//                    System.out.println("文件相同");
//                } else {
//                    System.out.println("error = " + e1 + "   " + " e2");
//                    System.out.println("文件不相同");
//                }
    }

    /**
     * 获得文件md5值
     */
    public static String getHash(String fileName, String hashType)
            throws Exception {
        InputStream fis;
        fis = new FileInputStream(fileName);
        byte[] buffer = new byte[1024];
        MessageDigest md5 = MessageDigest.getInstance(hashType);
        int numRead = 0;
        while ((numRead = fis.read(buffer)) > 0) {
            md5.update(buffer, 0, numRead);
        }
        fis.close();
        return toHexString(md5.digest());
    }

    /**
     * md5转成字符串
     */
    public static String toHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (int i = 0; i < b.length; i++) {
            sb.append(hexChar[(b[i] & 0xf0) >>> 4]);
            sb.append(hexChar[b[i] & 0x0f]);
        }
        return sb.toString();
    }

    public static char[] hexChar = { '0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };


}