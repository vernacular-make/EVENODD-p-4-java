package rto3;
import java.io.ByteArrayOutputStream;
import static rto3.Protocol.*;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;


import static rto3.Protocol.*;//静态导入，只能导入静态成员（一个常量类），.*是导入所有可以按需要导入
/**
 * Evenodd3func
 * 创建人:yaolan 
 * 时间：2020年4月8日-下午5:15:06 
 * @version 1.0.0
 *
 */
public class Evenodd3func {
	static byte slope_1=(byte)getMod(m-1-e1,m);
	static byte slope_2=(byte)getMod(m-1-2*e1,m);
	static byte slope_3=(byte)getMod(m-1-3*e1,m);

	//下面三行等价于import static rto3.Protocol.*
    //public static final int m = Protocol.m;
    //public static final int k = Protocol.k;
    //public static final int r = Protocol.r;
    /***
     * 有限域上的模运算
     * */
    public static int getMod(int a, int b) {
        if(a >= 0) {
            return a % b;
        }else{
            while(a < 0){
                a += b;
            }
            return a % b;
        }
    }
    
    /***
     * 有限域上的模逆运算
     * */
    public static int invert(int a, int p) {
		 int b=0;
		 if(gcd(a,p)==1) {
			 for (int k=1;k<10000;k++) {
				 if((p*(k-1)+1)/a<p && getMod((p*(k-1)+1),a)==0){
					 b=(p*(k-1)+1)/a;
					break;
				 }
			 }
		 }
		 return b;
	 }
    
    /***
     * 一元素是否是一集合里的元素   成员
     * */
    public static Object[] ismember(byte a,byte[] b) {
    	Object[] Object= {false,0} ;
        for(int i=0;i<b.length;i++) {
        	if (a==b[i]) {
			   Object[0]=true;
			   Object[1]=(byte)i;
        	   return Object;
        	} 	
        }
		return Object ;
    }

    public static boolean notmember(byte a,byte[] b) {
    	for(int i=0;i<b.length;i++) {
        	if (a==b[i]) {
        	   return false;
        	} 	
        }
    	return true;
    }
    
    /* OtoByte
     * 集合Object对象转其他类型数据   数组
     * 
     */
    public static void OtoByte(HashSet<Byte> BS,byte[][] S,byte mark) {
    	int i=0;
    	for (Byte n:BS) {
  		  S[mark][i]=n;
  		  i++;  
  	    }
    }
    
    /*MIN_SET
     * 某个集合里的最小值
     * */
    public static byte MIN_SET(HashSet<Byte> A) {
    	Optional<Byte> optional=A.stream().min(new Comparator<Byte>(){
        	@Override
        	public int compare(Byte o1,Byte o2) {
        		return o1-o2;
        	    //return o2-o1;//max	
        	}
        });
        byte i1= optional.get();
    	return i1;
   	}
    
    /*remove
     * 某个大集合移除多个子集合
     * */
    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A) {
    	HashSet<Byte> U_1=new HashSet();
    	U_1.addAll(U);
    	U_1.removeAll(A);
    	return U_1;
   	}
    
    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A,HashSet<Byte> B) {
    	HashSet<Byte> U_1=new HashSet();
    	U_1.addAll(U);
    	U_1.removeAll(A);
        U_1.removeAll(B);
    	return U_1;
   	}
    
    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A,HashSet<Byte> B,HashSet<Byte> C) {
    	HashSet<Byte> U_1=new HashSet();
    	U_1.addAll(U);
    	U_1.removeAll(A);
        U_1.removeAll(B);
        U_1.removeAll(C);
    	return U_1;
   	}
    
    public static HashSet<Byte> remove(HashSet<Byte> U,HashSet<Byte> A,HashSet<Byte> B,HashSet<Byte> C,HashSet<Byte> D) {
    	HashSet<Byte> U_1=new HashSet();
    	U_1.addAll(U);
    	U_1.removeAll(A);
        U_1.removeAll(B);
        U_1.removeAll(C);
        U_1.removeAll(D);
    	return U_1;
   	}
    
    //效率低
    public static int gcdlow(int a, int b) {
    	return b==0?a:gcd(b,a%b);
    }
    
    /*效率高  两个数是否互质
     * 
     */
    public static int gcd(int a, int b) {
    	int temp=0;
    	do {
    	   if(b==0) {
    		  return a;
    	   }else {
    		temp=a%b;
    		a=b;
    		b=temp;
    	   }
    	}while(b>0);
    	return a;
    }
    
    /***
     * 打印矩阵
     * */
    //二维
    public static void display(byte[][] temp)
	{	
		for(int i=0;i<temp.length;i++)
		{
			for(int j=0;j<temp[i].length;j++)
			{
				System.out.printf("%6d",temp[i][j]);
			}
			System.out.print(" \n");
		}
		System.out.print(" \n");
	}
	//一维
	public static void display1(byte[] temp)
	{	
		for(int i=0;i<temp.length;i++)
		{
			
				System.out.printf("%6d",temp[i]);
		}
			System.out.print(" \n");
	}
    
    
    /**
     * 对矩阵进行转置
     * */
    public static void transposed(byte[][] temp, byte[][] tempMemory){
        for (int i = 0; i < tempMemory[0].length; i++) {
            for (int j = 0; j < tempMemory.length; j++) {
                temp[i][j] = tempMemory[j][i];
            }
        }
    }
    
    /**
     * EVENODD r=3 集合分配选择
     * @throws IOException 
     * */
    public static void Spart_3(byte[][] S) throws IOException{
    	HashSet<Byte> U=new HashSet<>();
    	HashSet<Byte> U_1=new HashSet<>();
    	for(byte i=0;i<m-1;i++) {
    		U.add(i);
    	}
    	
    	byte i1=0;
    	byte ord=0;
    	if (e1==0) {
    	   i1=0;
    	}else {
    	   i1=(byte)getMod(m-1-e1,m);
    	}
    	
    	for(int i=1;i<m;i++) {
    	   if ((byte)getMod((int)Math.pow(2, 0)-1,m)==(byte)getMod((int)Math.pow(2, i)-1,m)) {
    		  ord=(byte)i;
    		  break;
    	   }
    	}
    	
    	HashSet<Byte> BS_0=new HashSet<Byte>();
    	HashSet<Byte> BS_1=new HashSet<Byte>();
    	HashSet<Byte> BS_2=new HashSet<Byte>();
    	
    while(BS_1.size()<LS) {
    	for(int i=0;i<ord;i++) {
    		if((byte)getMod((i1+1)*(int)Math.pow(2, i)-1,m)==slope_1) {
    			BS_0.add(slope_1);
    		}else{
    			  if ((byte)getMod((i1+1)*(int)Math.pow(2, i)-1,m)!=slope_2){
    				  BS_1.add((byte)getMod((i1+1)*(int)Math.pow(2, i)-1,m));
    				  if(BS_1.size()==LS){
    					 if((i<ord-1) && BS_0.size()<Math.floor((m-1)/3)) {
    					    BS_0.add((byte)getMod((i1+1)*(int)Math.pow(2, i+1)-1,m));
    					    break;
    					 }
    				     break;
    				  }
    		      }	
    		}
    	}
       U_1=remove(U,BS_0,BS_1);
       i1=MIN_SET(U_1);
    }
 
    if (e1!=0) {
    	if(BS_0.size()<LS) {
    	   BS_0.add(slope_2);
    	}else {
    	   BS_2.add(slope_2);
    	}
    }
     
    U_1.clear();
    HashSet<Byte> BS_0_break=new HashSet<Byte>();
    while(BS_0.size()<LS) {
    	BS_0_break.addAll(BS_0);
    	if (BS_0_break.size()==0) {
    	    U_1=remove(U,BS_0,BS_1,BS_2);
    		BS_0_break.add(MIN_SET(U_1));
    		U_1.clear();
    	}
    	
    	for (Byte i_0 : BS_0_break) {
			for (Byte i_1 : BS_1) {
				byte i_2=(byte)getMod(2*i_1-i_0,m);
				U_1=remove(U,BS_0,BS_1,BS_2);
				if (BS_0.size()<LS && U_1.contains(i_2)){
					BS_0.add(i_2);
				}
				U_1.clear();
			}
		}
    	BS_0_break.clear();
    	if (BS_0.size()<LS){
    		BS_0_break.addAll(BS_0);
    		for (byte i_0 : BS_0_break) {
				byte i_2=(byte)getMod(2*m-2-i_0,m);
				U_1=remove(U,BS_0,BS_1,BS_2);
				if (BS_0.size()<LS && U_1.contains(i_2)){
					BS_0.add(i_2);
				}
				U_1.clear();
			}
    		BS_0_break.clear();
    	}
    	if (BS_0.size()==LS) {
    		break;
    	}
     }
    //System.out.println("0======");
    //BS_0.stream().forEach(System.out::println);
      BS_2.clear();
      BS_2=remove(U,BS_0,BS_1);
      
      OtoByte(BS_0,S,(byte) 0);
      OtoByte(BS_1,S,(byte) 1);
      OtoByte(BS_2,S,(byte) 2);
    }
    
    /**
     * EVENODD r=4 集合分配选择
     * @throws IOException 
     * */
    public static void Spart_4(byte[][] S) throws IOException{
    	HashSet<Byte> U=new HashSet<Byte>();
    	HashSet<Byte> U_1=new HashSet<Byte>();
    	for(byte i=0;i<m-1;i++) {
    		U.add(i);
    	}
    	
    	byte i2=0;
    	byte ord=0;
    	if (e1==0) {
    	   i2=0;
    	}else {
    	   i2=(byte)getMod(m-1-2*e1,m);
    	}
    	
    	for(int i=1;i<m;i++) {
    	   if ((byte)getMod((int)Math.pow(2, 0)-1,m)==(byte)getMod((int)Math.pow(2, i)-1,m)) {
    		  ord=(byte)i;
    		  break;
    	   }
    	}
    	
    	HashSet<Byte> BS_0=new HashSet<Byte>();
    	HashSet<Byte> BS_1=new HashSet<Byte>();
    	HashSet<Byte> BS_2=new HashSet<Byte>();
    	HashSet<Byte> BS_3=new HashSet<Byte>();
    	
    while(BS_2.size()<HS) {
    	for(int i=0;i<ord;i++) {
    		if((byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m)==slope_2) {
    			BS_0.add(slope_2);
    		}else{
    			  if ((byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m)!=slope_2 && (byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m)!=slope_2){
    				  BS_2.add((byte)getMod((i2+1)*(int)Math.pow(2, i)-1,m));
    				  if(BS_2.size()==HS){
    					 U_1.clear();
    					 U_1=remove(U,BS_2);
    					 if((i<ord-1) && BS_0.size()<LS && U_1.contains((byte)getMod((i2+1)*(int)Math.pow(2, i)*invert(2,m),m))) {
    						BS_0.add((byte)getMod((i2+1)*(int)Math.pow(2, i)*invert(2,m),m));
    						break;
    					 }
    				     break;
    				  }
    		      }	
    		}
    	}
       U_1.clear();
       U_1=remove(U,BS_0,BS_2);
       i2=MIN_SET(U_1);
    }
    
    //System.out.println("2======");
    //BS_2.stream().forEach(System.out::println);
    
    U_1.clear();
    HashSet<Byte> BS_0_break=new HashSet<Byte>();
    while(BS_0.size()<LS) {
    	BS_0_break.addAll(BS_0);
    	if (BS_0_break.size()==0) {
    	    U_1=remove(U,BS_2);
    		BS_0_break.add(MIN_SET(U_1));
    	}
    	U_1.clear();
    	for (Byte i_0 : BS_0_break) {
			for (Byte i_2_ : BS_2) {
				byte i_2=(byte)getMod(i_2_+2*e1,m);
				byte i_1=(byte)getMod((i_0+i_2)*invert(2,m),m);
				U_1=remove(U,BS_0,BS_2);
				if(i_1==(byte)getMod(e1-1,m)){
						if (m<11) {
							if (BS_0.size()<LS && U_1.contains(slope_1))
								BS_0.add(slope_1);
						}else{
					    	if (BS_0.size()<LS && U_1.contains(slope_1) && i_1!=(byte)getMod(-2-i_2,m) && i_1!=(byte)getMod(3*i_2+2,m))
					    		BS_0.add(slope_1);
					    }
				}else {
						if (m<11) {
							if (BS_0.size()<LS && U_1.contains((byte)getMod(i_1-e1,m)))
								BS_0.add((byte)getMod(i_1-e1,m));
						}else{
							if (BS_0.size()<LS && U_1.contains((byte)getMod(i_1-e1,m)) && i_1!=(byte)getMod(-2-i_2,m) && i_1!=(byte)getMod(3*i_2+2,m))
								BS_0.add((byte)getMod(i_1-e1,m));
						}
				}
				U_1.clear();
			}
		}
    	BS_0_break.clear();
    	if (BS_0.size()==LS) {
    		break;
    	}
     }
    //System.out.println("0======");
    //BS_0.stream().forEach(System.out::println);
    
    //填满BS_1
    U_1.clear();
    U_1=remove(U,BS_0,BS_2);
    if (e1!=0) {
    	if(U_1.contains(slope_1)) 
    	   BS_1.add(slope_1);
    	BS_3.add(slope_3);
    }
    
    //System.out.println(slope_1);
    // System.out.println("1======");
    //BS_1.stream().forEach(System.out::println);
    //System.out.println("3======");
    //BS_3.stream().forEach(System.out::println);
    
    U_1.clear();
    while(BS_1.size()<LS) {
    	for (Byte i_0 : BS_0) {
			for (Byte i_2_ : BS_2) {
				byte i_2=(byte)getMod(i_2_+2*e1,m);
				byte i_3=(byte)getMod((3*i_2-i_0)*invert(2,m),m);
				System.out.print(i_3+"*");
				U_1=remove(U,BS_0,BS_2,BS_1,BS_3);
				  if (m<=11) {
					    if (BS_1.size()<LS && U_1.contains((byte)getMod(i_3-3*e1,m)))
						    BS_1.add((byte)getMod(i_3-3*e1,m));
				  }else{
					    if (BS_1.size()<LS && U_1.contains((byte)getMod(i_3-3*e1,m)) && i_3!=(byte)getMod((i_0-1)*invert(2,m),m) && i_3!=(byte)getMod((2*i_0-1)*invert(3,m),m) && i_3!=(byte)getMod((i_2-1)*invert(2,m),m))
					       {
					    	BS_1.add((byte)getMod(i_3-3*e1,m));
					        System.out.println(i_3+"++");
					       }
				  }
				U_1.clear();
		    }
    	}
    	if (BS_1.size()<LS) {
    	   U_1.clear();
  	       U_1=remove(U,BS_0,BS_2,BS_3,BS_1);
  	       BS_1.add(MIN_SET(U_1));
    	}
     }
    System.out.println("1======");
    BS_1.stream().forEach(System.out::println);
       
    //剩下BS_3
    BS_3.clear();;
    BS_3=remove(U,BS_0,BS_1,BS_2);

      OtoByte(BS_0,S,(byte) 0);
      OtoByte(BS_1,S,(byte) 1);
      OtoByte(BS_2,S,(byte) 2);
      OtoByte(BS_3,S,(byte) 3);
    }
    
    /*S---Sdeal
     * 转可以处理的数组形式
     * */
    public static void dealS(byte[][] S,byte[][] S_deal) {
        for (int i = 0; i <LS; i++) {
        	 S_deal[0][i]=S[0][i];
    		 if(S[1][i]!=slope_1) {
    			S_deal[1][i]=(byte)getMod(S[1][i]+e1,m);
    		 }else {
    			S_deal[1][i]=(byte)getMod(e1-1,m); 
    		 }
		}
        
        for (int i = 0; i <HS; i++) {
    		 if(S[2][i]!=slope_2) {
    			S_deal[2][i]=(byte)getMod(S[2][i]+2*e1,m);
    		 }else {
    			S_deal[2][i]=(byte)getMod(2*e1-1,m); 
    		 }
    		 if(r==4) {
    			 if(S[3][i]!=slope_3) {
    				 S_deal[3][i]=(byte)getMod(S[3][i]+3*e1,m);
    			 }else {
    				 S_deal[3][i]=(byte)getMod(3*e1-1,m); 
    			 }
    		 }
		 }
    }
    
    /**
     * 水平校验列 校验0列
     * @param dataCache
     * */
    public void horiXOR(byte[][] dataCache, int nodesize) {
        /*transposed*/
        for (int i = 0; i < nodesize; i++) {
            for (int j = 0; j < k; j++) {
                dataCache[i][k] ^= dataCache[i][j];
            }
        }
    }
    
    /**
     * 求公共因子s m-1,k+1  (r=2)
     * */
    public static void getFactor0(byte[] factor1, byte[][] dataCache, int blocksize) {
        for (int i = 1; i < k; i++) {
            //System.out.println("*****" + getMod(m-1-i,m) + "***");
            for (int j = 0; j < blocksize; j++) {
                factor1[j] ^= dataCache[getMod(m-1-i,m)*blocksize+j][i];  //p-1-i 斜率为1
            }
        }
    }

    /**
     * 求公共因子s m-1,k+1 and m-1.k+2 (r=3)
     * */
    public static void getFactor1(byte[] factor1, byte[] factor2, byte[][] dataCache, int blocksize) {
        for (int i = 1; i < k; i++) {
            //System.out.println("*****" + getMod(m-1-i,m) + "***");
            for (int j = 0; j < blocksize; j++) {
                factor1[j] ^= dataCache[getMod(m-1-i,m)*blocksize+j][i];  //p-1-i 斜率为1
            }
        }
        for (int i = 1; i < k; i++) {
            for (int j = 0; j < blocksize; j++) {
                factor2[j] ^= dataCache[getMod(m-1-2*i,m)*blocksize+j][i];  //p-1+1 斜率为2
            }
        }
        /*test factor*/
        //for(int L=0;L<15;L++) 
        //System.out.print(factor1[L]+" "); 
    }
    
    /**
     * 求公共因子s m-1,k+1 ; m-1.k+2 ;m-1.k+3(slope-1;slope-2;slope-3)   R=4
     * */
    public static void getFactor2(byte[] factor1, byte[] factor2, byte[] factor3, byte[][] dataCache, int blocksize) {
        for (int i = 1; i < k; i++) {
            //System.out.println("*****" + getMod(m-1-i,m) + "***");
            for (int j = 0; j < blocksize; j++) {
                factor1[j] ^= dataCache[getMod(m-1-i,m)*blocksize+j][i];    //p-1-i 斜率为1
            }
        }
        for (int i = 1; i < k; i++) {
            for (int j = 0; j < blocksize; j++) {
                factor2[j] ^= dataCache[getMod(m-1-2*i,m)*blocksize+j][i];  //p-1+2*i 斜率为2
            }
        }
        for (int i = 1; i < k; i++) {
            for (int j = 0; j < blocksize; j++) {
                factor3[j] ^= dataCache[getMod(m-1-3*i,m)*blocksize+j][i];  //p-1+3*i 斜率为3
            }
        }
       /*test factor*/
   	   //for(int L=0;L<15;L++) 
       //System.out.print(factor2[L]+" "); 
    }
    
    /*//byte[r-1][r-1][blocksize]factor
    public void getFactorALL(byte[][][] factor, byte[][] dataCache, int blocksize) {
    	for(int h=1;h<r-1;h++) {
           for (int i = 1; i < k; i++) {
             //System.out.println("*****" + getMod(m-1-i,m) + "***");
             for (int j = 0; j < blocksize; j++) {
            	for(int l=1;l<r-1;l++) {
                factor[h][l][j] ^= dataCache[getMod(m-1-h*i,m)*blocksize+j][i];}    //p-1-i 斜率为1
             }
           }
        }
    }*/
    
   public void diagXOR0(byte[][] dataCache, int shardsize, int blocksize) {      
        byte[] factor1 = new byte[blocksize];
        getFactor0(factor1,dataCache,blocksize);

        for (int i = 0; i < m-1; i++) {
            for (int j = 0; j < blocksize; j++) {
                dataCache[i*blocksize+j][k+1]=dataCache[i*blocksize+j][0];
                dataCache[i*blocksize+j][k+1] ^= factor1[j];
                }
            for(int h = 1; h < k; h++){
                int index = getMod(i-h,m);
                if(index != m - 1){
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[i*blocksize+j][k+1] ^= dataCache[index*blocksize+j][h];
                    }
                }
            }
        }
}
    
    /**
     * 斜校验列
     * R=3 校验1列 校验2列
     * */
    public void diagXOR(byte[][] dataCache, int shardsize, int blocksize) {
        
        byte[] factor1 = new byte[blocksize];
        byte[] factor2 = new byte[blocksize];
        getFactor1(factor1,factor2,dataCache,blocksize);

        for (int i = 0; i < m-1; i++) {
            for (int j = 0; j < blocksize; j++) {
                dataCache[i*blocksize+j][k+1]=dataCache[i*blocksize+j][0];
                dataCache[i*blocksize+j][k+1] ^= factor1[j];
                }
          
            for(int h = 1; h < k; h++){
                int index = getMod(i-h,m);
                if(index != m - 1){
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[i*blocksize+j][k+1] ^= dataCache[index*blocksize+j][h];
                    }
                }
            }
        }
      

        for (int i = 0; i < m-1; i++) {
            for (int j = 0; j < blocksize; j++) {
                dataCache[i*blocksize+j][k+2]=dataCache[i*blocksize+j][0];
                dataCache[i*blocksize+j][k+2] ^= factor2[j];
                }
            for(int h = 1; h < k; h++){
                int index = getMod(i-2*h,m);
                if(index != m - 1){
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[i*blocksize+j][k+2] ^= dataCache[index*blocksize+j][h];
                    }
                }
            }
        }
    }

    /**
     * 斜校验列
     * R=4 校验1列 校验2列 校验3列
     * */
    public void diagXOR1(byte[][] dataCache, int shardsize, int blocksize) {
            byte[] factor1 = new byte[blocksize];
            byte[] factor2 = new byte[blocksize];
            byte[] factor3 = new byte[blocksize];
            //getFactor1(factor1,factor2,dataCache,blocksize);
            getFactor2(factor1,factor2,factor3,dataCache,blocksize);
            
            for (int i = 0; i < m-1; i++) {
            	//第0列不需要寻址直接异或在校验列上
                for (int j = 0; j < blocksize; j++) {
                    dataCache[i*blocksize+j][k+1]=dataCache[i*blocksize+j][0];
                    dataCache[i*blocksize+j][k+1] ^= factor1[j];
                }
                //对1_k-1列对应信息位寻址            
                for(int h = 1; h < k; h++){
                    int index = getMod(i-h,m);                 //slope_1
                    if(index != m - 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[i*blocksize+j][k+1] ^= dataCache[index*blocksize+j][h];
                        }
                    }
                }
            }
            //System.out.println("slope-1:");
            //display(dataCache);
            for (int i = 0; i < m-1; i++) {
                for (int j = 0; j < blocksize; j++) {
                    dataCache[i*blocksize+j][k+2]=dataCache[i*blocksize+j][0];
                    dataCache[i*blocksize+j][k+2] ^= factor2[j];
                    }
                for(int h = 1; h < k; h++){
                    int index = getMod(i-2*h,m);      //slope_ 2
                    if(index != m - 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[i*blocksize+j][k+2] ^= dataCache[index*blocksize+j][h];
                        }
                    }
                }
            }

            //System.out.println("slope-2:");
            //display(dataCache);
            
            for (int i = 0; i < m-1; i++) {
                for (int j = 0; j < blocksize; j++) {
                    dataCache[i*blocksize+j][k+3]=dataCache[i*blocksize+j][0];
                    dataCache[i*blocksize+j][k+3] ^= factor3[j];
                    }
                for(int h = 1; h < k; h++){
                    int index = getMod(i-3*h,m);      //slope- 3
                    if(index != m - 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[i*blocksize+j][k+3] ^= dataCache[index*blocksize+j][h];
                        }
                    }
                }
            }  
        }
    
    /**
     * 解码
     * @param dataCache
     * */
    public void decode(byte[] f1, byte[][] dataCache, int shardsize, int blocksize, int e1, int e2){

        byte[] factors = new byte[blocksize];   // b_m-1,k+1 + b_m-1,k+2
//        byte[] p0 = new byte[blocksize*(m-1)];
        byte[] p1 = new byte[blocksize*(m-1)];
        byte[] p2 = new byte[blocksize*(m-1)];

        //校验一列 二列 数据 （备份？）
        for (int i = 0; i < shardsize; i++) {
//            p0[i] = dataCache[i][k];
            p1[i] = dataCache[i][k+1];
            p2[i] = dataCache[i][k+2];
        }

        // 两校验列异或  得到校验一列 二列公共因子之和
        for (int i = 0; i < m-1; i++) {
            for (int j = 0; j < blocksize; j++) {
                factors[j] ^= p1[i*blocksize+j];
                factors[j] ^= p2[i*blocksize+j];
            }
        }

//        System.arraycopy(factors, 0, f1, 0, blocksize);

        // 在p1和p2中删除存活块  剩下失效位的异或和
        for (int i = 0; i < m-1; i++) {
            for(int h = 0; h < k; h++){
                if(h != e1 && h != e2){
                    int index = getMod(i-h,m);
                    if(index != m - 1){
                        for (int j = 0; j < blocksize; j++) {
                            p1[i*blocksize+j] ^= dataCache[index*blocksize+j][h];
                        }
                    }
                }
            }
        }
        for (int i = 0; i < m-1; i++) {
            for(int h = 0; h < k; h++){
                if(h != e1 && h != e2) {
                    int index = getMod(i + h, m);
                    if (index != m - 1) {
                        for (int j = 0; j < blocksize; j++) {
                            p2[i * blocksize + j] ^= dataCache[index*blocksize+j][h];
                        }
                    }
                }
            }
        }

        // 开始解码
        int[] start = {m-1+e1, m-1+e2, m-1-e1, m-1-e2};
        int[] startCol = {1, 1, -1, -1};
        byte[] res = new byte[blocksize];

        for (int i = 0; i < 4; i++) {
            int s1 = 0, s2 = 0;
            int right = startCol[i];
            int left = startCol[i];
            int index = start[i];
            if(index == m - 1){
                continue;
            }
            if(right == 1){
                System.arraycopy(p1, getMod(index,m)*blocksize, res, 0, blocksize);
                s1++;
            }else{
                System.arraycopy(p2, getMod(index,m)*blocksize, res, 0, blocksize);
                s2++;
            }
            while(getMod(index,m) != m-1){
                if(right == 1){
                    if(i == 0 || i == 3){
                        index -= 2*e2;
                    }else{
                        index -= 2*e1;
                    }
                    index = getMod(index, m);
                    if(index >= m-1-(2* Math.floor(k/2)) && index < m - 1){
                        s2++;
                    }
                    if(index != m - 1){
                        for (int j = 0; j < blocksize; j++) {
                            res[j] ^= p2[index*blocksize+j];
                        }
                    }
                    left = 1;
                    right = 0;
                }else if(left == 1 || left == -1){
                    if(i == 0 || i == 3){
                        index += 2*e1;
                    }else{
                        index += 2*e2;
                    }
                    index = getMod(index, m);
                    if(index < (2* Math.floor(k/2))){
                        s1++;
                    }
                    if(index != m - 1){
                        for (int j = 0; j < blocksize; j++) {
                            res[j] ^= p1[index*blocksize+j];
                        }
                    }
                    left = 0;
                    right = 1;
                }
            }


            // 补偿
            int min = Math.min(s1,s2);

            //if((startCol[i] == 1 && right == 1) || (startCol[i] == -1 && left == 1)){
            if (s1 % 2 != 0 && s2 % 2 != 0) {
//                System.out.println("hhhhhhhhhhhhhhhhhhhhhhhh");
                    for (int l = 0; l < blocksize; l++) {
                        res[l] ^= factors[l];
                    }

            } else if (s1 % 2 == 0 && s2 % 2 != 0) {
//                System.out.println("hhhhhhhhhhhhhhhhhhhhhhhh");
                    for (int l = 0; l < blocksize; l++) {
                        res[l] ^= factors[l];
                    }
            }


            int num = (s1-s2)>0?s1-s2:s2-s1;
            // 起点与终点不再同一列
            if((startCol[i] == 1 && right == 1) || (startCol[i] == -1 && left == 1)){
                if(num % 2 == 0){
//                    System.out.println("111111111");
                    if(i == 0){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e1,m)*blocksize+j][e1] = res[j];
                        }
                    }else if(i == 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e2,m)*blocksize+j][e2] = res[j];
                        }
                    }else if(i == 2){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e1,m)*blocksize+j][e1] = res[j];
                        }
                    }else{
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e2,m)*blocksize+j][e2] = res[j];
                        }
                    }
                }else{
//                    System.out.println("22222222222");
                    if(i == 0){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e2,m)*blocksize+j][e2] = res[j];
                        }
                    }else if(i == 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e1,m)*blocksize+j][e1] = res[j];
                        }
                    }else if(i == 2){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e2,m)*blocksize+j][e2] = res[j];
                        }
                    }else{
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e1,m)*blocksize+j][e1] = res[j];
                        }
                    }
                }
                // 起点与终点在同一列
            }else{
                if(num % 2 == 0){
//                    System.out.println("333333333333");
                    if(i == 0){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e2,m)*blocksize+j][e2] = res[j];
                        }
                    }else if(i == 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e1,m)*blocksize+j][e1] = res[j];
                        }
                    }else if(i == 2){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e2,m)*blocksize+j][e2] = res[j];
                        }
                    }else{
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e1,m)*blocksize+j][e1] = res[j];
                        }
                    }
                }else{
//                    System.out.println("444444444444");
                    if(i == 0){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e1,m)*blocksize+j][e1] = (byte) (res[j] ^ factors[j]);
                        }
                    }else if(i == 1){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1+e2,m)*blocksize+j][e2] = (byte) (res[j] ^ factors[j]);
                        }
                    }else if(i == 2){
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e1,m)*blocksize+j][e1] = (byte) (res[j] ^ factors[j]);
                        }
                    }else{
                        for (int j = 0; j < blocksize; j++) {
                            dataCache[getMod(m-1-e2,m)*blocksize+j][e2] = (byte) (res[j] ^ factors[j]);
                        }
                    }
                }
            }
        }

        // 参与计算公共因子的失效数据块全部恢复出来，重新计算单独的公共因子
        byte[] factor1 = new byte[blocksize];
        byte[] factor2 = new byte[blocksize];
        getFactor1(factor1,factor2,dataCache,blocksize);

//        System.arraycopy(factor2, 0, f1, 0, blocksize);

        // 在p1 p2中删除公共因子
        for (int i = 0; i < m-1; i++) {
            if(i < (2* Math.floor(k/2))){
                for (int j = 0; j < blocksize; j++) {
                    p1[i*blocksize+j] ^= factor1[j];
                }
            }
            if(i >= m-1-(2* Math.floor(k/2))){
                for (int j = 0; j < blocksize; j++) {
                    p2[i*blocksize+j] ^= factor2[j];
                }
            }
        }

        for (int i = 0; i < 4; i++) {
            int right = startCol[i];
            int left = startCol[i];
            int index = start[i];

            if(index == m - 1){
                continue;
            }

            if (right == 1) {
                //System.out.println("index==========" + getMod(index,m));
                System.arraycopy(p1, getMod(index,m)*blocksize, res, 0, blocksize);
                if(i == 0){
                   // System.out.println("B_" + getMod(index-e2,m) + "," + e2);
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[getMod(index-e2,m)*blocksize+j][e2] = p1[getMod(index,m)*blocksize+j];
                    }
                }else{
                   // System.out.println("B_" + getMod(index-e1,m) + "," + e1);
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[getMod(index-e1,m)*blocksize+j][e1] = p1[getMod(index,m)*blocksize+j];
                    }
                }
            } else {
                //System.out.println("index==========" + getMod(index,m));
                System.arraycopy(p2, getMod(index,m)*blocksize, res, 0, blocksize);
                if(i == 2){
                    //System.out.println("B_" + getMod(index+e2,m) + "," + e2);
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[getMod(index+e2,m)*blocksize+j][e2] = p2[getMod(index,m)*blocksize+j];
                    }
                }else{
                   // System.out.println("B_" + getMod(index+e1,m) + "," + e1);
                    for (int j = 0; j < blocksize; j++) {
                        dataCache[getMod(index+e1,m)*blocksize+j][e1] = p2[getMod(index,m)*blocksize+j];
                    }
                }
            }
            while (index != m - 1) {
                if (right == 1) {
                    if (i == 0 || i == 3) {
                        index -= 2 * e2;
                        index = getMod(index, m);
                        if (index != m - 1) {
//                            System.out.println("i = " + i + " index = " + index);
//                            System.out.println("B_" + getMod(index+e1,m) + "," + e1);
                            for (int j = 0; j < blocksize; j++) {
                                dataCache[getMod(index+e1,m)*blocksize+j][e1] = (byte) (p2[index * blocksize+j] ^ res[j]);
                                res[j] = dataCache[getMod(index+e1,m)*blocksize+j][e1];
                            }

                        }
                    } else{
                        index -= 2 * e1;
                        index = getMod(index, m);
                        if (index != m - 1) {
//                            System.out.println("i = " + i + " index = " + index);
//                            System.out.println("B_" + getMod(index+e2,m) + "," + e2);
                            for (int j = 0; j < blocksize; j++) {
                                dataCache[getMod(index+e2,m)*blocksize+j][e2] = (byte) (p2[index * blocksize + j] ^ res[j]);
                                res[j] = dataCache[getMod(index+e2,m)*blocksize+j][e2];
                            }
                        }
                    }
                    left = 1;
                    right = 0;
                } else if (left == 1 || left == -1) {
                    if (i == 0 || i == 3) {
                        index += 2 * e1;
                        index = getMod(index, m);
                        if (index != m - 1) {
//                            System.out.println("i = " + i + " index = " + index);
//                            System.out.println("B_" + getMod(index-e2,m) + "," + e2);
                            for (int j = 0; j < blocksize; j++) {
                                dataCache[getMod(index-e2,m)*blocksize+j][e2] = (byte) (p1[index * blocksize + j] ^ res[j]);
                                res[j] = dataCache[getMod(index-e2,m)*blocksize+j][e2];
                            }
                        }
                    } else {
                        index += 2 * e2;
                        index = getMod(index, m);
                        if (index != m - 1) {
//                            System.out.println("i = " + i + " index = " + index);
//                            System.out.println("B_" + getMod(index-e1,m) + "," + e1);
                            for (int j = 0; j < blocksize; j++) {
                                dataCache[getMod(index-e1,m)*blocksize+j][e1] = (byte) (p1[index * blocksize + j] ^ res[j]);
                                res[j] = dataCache[getMod(index-e1,m)*blocksize+j][e1];
                            }
                        }
                    }
                    left = 0;
                    right = 1;
                }
            }
        }
        //System.arraycopy(dataCache, 11*blocksize, f1, 0, blocksize);
    }


/**
 * 修复一单独失效列
 * 传入的是 现存的数据，nodesize, blocksize,失效列，修复集合S:比如s_0={},s_1={},s_2={},s_3={}. Sdeal[4][] floor((p-1)/4) ceil((p-1)/4)
 * 1、首先确定公共元素
 * 2、统计修复修复位数
 * 3、挑位计算
 * @param dataCache
 * */
 public int repair_4(byte[][] dataCache, int shardsize, int blocksize, int e1, byte[][] Sdeal,byte[][] S){
    	//修复选用R修复的丢失位Sdeal[0]
    	//System.out.println(Sdeal[0][0]);
    	//System.out.println(dataCache[e1][Sdeal[0][0]*blocksize+1]);
    	for(int i=0;i<Sdeal[0].length;i++) {
    		for (int j = 0; j < blocksize; j++) {
    	        for(int h=0;h<k+1;h++) {
    	           if(h!=e1)
    		       dataCache[e1][Sdeal[0][i]*blocksize+j] ^= dataCache[h][Sdeal[0][i]*blocksize+j];
//    		       if (j==1) {
//       	        	System.out.print(dataCache[e1][Sdeal[0][0]*blocksize+1]);
//       	        	//System.out.println();
//       	        	System.out.println(dataCache[h][Sdeal[0][0]*blocksize+1]);
//       	       }
    	        } 
    	  }	
    	}
    	
    	byte[] factor1= new byte[blocksize];
    	byte[] factor2= new byte[blocksize];
    	byte[] factor3= new byte[blocksize];
    	Object[] O1= {false,0};
    	//确认公共元素 斜率为1 2 3的公共因子  factor1 factor2 factor3
    	//p-1-2*j一定在S_0中   ; p-1-j可能在S_0中，不然在S_1中 ;j!=0时 S3中有p-1-3*j	  j==e1
    	if(e1==0) {
    		for (int i = 1; i < k; i++) {
                for (int j = 0; j < blocksize; j++) {
                    factor1[j] ^= dataCache[i][getMod(m-1-i,m)*blocksize+j];    //p-1-i 斜率为1
                }
            }
            for (int i = 1; i < k; i++) {
                for (int j = 0; j < blocksize; j++) {
                    factor2[j] ^= dataCache[i][getMod(m-1-2*i,m)*blocksize+j];  //p-1+2*i 斜率为2
                }
            }
            for (int i = 1; i < k; i++) {
                for (int j = 0; j < blocksize; j++) {
                    factor3[j] ^= dataCache[i][getMod(m-1-3*i,m)*blocksize+j];  //p-1+3*i 斜率为3
                }
            }
    	} 
    	//p-1-2*e1一定在S_0(Sdeal[0])中   ; p-1-e1可能在S_0(Sdeal[0])中，不然在S_1(即是e1-1在Sdeal[1])中 ;e1!=0时 S3中有p-1-3*e1(即是3*e1-1在Sdeal[3])	  j==e1
    	else{
    		/*factor1*/
    		O1=ismember((byte)getMod(m-1-e1,m),S[0]);
    		if((Boolean) O1[0]) {
    		   for (int i = 1; i < k; i++){
                    for (int j = 0; j < blocksize; j++) {
                        factor1[j] ^= dataCache[i][getMod(m-1-i,m)*blocksize+j];  //p-1+2*i 斜率为2
                    }
                }
       	    }
    		else{                            //p-1-e1在S_1(e1-1在Sdeal中)，求公共位  
       	    	//e1-1  先异或上斜率为1的检验位
       	    	for (int j = 0; j < blocksize; j++) {
                    factor1[j] ^= dataCache[k+1][getMod(e1-1,m)*blocksize+j];  
//                    if (j==3) {
//	   		    	     System.out.println(factor1[j]+" ");
//	   		    	     System.out.println((-53)^94^(-60)^(65)^(-80)^(68));
//	   		          }
                }
       	    	//e1-1  对应斜率为1的信息位
       	        for(int h = 0; h < k; h++){
       	           int index = getMod(e1-1-h,m);
       	           if(index != m - 1){
       	              for (int j = 0; j < blocksize; j++) {
       	                  factor1[j] ^= dataCache[h][index*blocksize+j];	
       	              }
       	           }
       	        }
       	       //System.out.println();
       	       //System.out.println(factor1[3]+" ");
       	    }
    		
    		/*factor2*/
    		for (int i = 1; i < k; i++) {
                for (int j = 0; j < blocksize; j++) {
                    factor2[j] ^= dataCache[i][getMod(m-1-2*i,m)*blocksize+j];  //p-1+2*i 斜率为2
                }
            }
    		
    		/*factor3*/
    		//3*e1-1  先异或上斜率为3的检验位
   	    	for (int j = 0; j < blocksize; j++) {
                factor3[j] ^= dataCache[k+3][getMod(3*e1-1,m)*blocksize+j];  
            }
   	    	//3*e1-1  对应斜率为3的信息位
   	        for(int h = 0; h < k; h++){
                int index = getMod(3*e1-1-3*h,m);
                if(index != m - 1){
                    for (int j = 0; j < blocksize; j++) {
                    	factor3[j] ^= dataCache[h][index*blocksize+j];
                    }
                }
            }		
    	}
    	
      /*test factor*/
    	//for(int L=0;L<15;L++) 
    	//	System.out.print(factor2[L]+" ");
    	
      /*修复选用E修复的丢失位S[1]*/
       //    	if (j==3) {
       //    		System.out.println(dataCache[k+1][Sdeal[1][i]*blocksize+j]);
       //    		System.out.println(factor1[3]);
       //    		System.out.println(68^(-4));
       //    		System.out.println(24^(-53)^(94)^(-60)^(65)^(-80));
       //    		System.out.println((-3)^105^(-10)^(-128)^(30)^(0));
       //	        }
    	for(int i=0;i<S[1].length;i++) {
    		if(Sdeal[1][i]==e1-1) {
    			for (int h = 1; h < k; h++) {
    				if(h!=e1) {
    					for (int j = 0; j < blocksize; j++) {
    						dataCache[e1][S[1][i]*blocksize+j]^=factor1[j];  //p-1-i 斜率为1
    						dataCache[e1][S[1][i]*blocksize+j]^= dataCache[h][getMod(m-1-h,m)*blocksize+j];
    					}
    				}
    	        }
    		}else{
    			for (int j = 0; j < blocksize; j++){
    				dataCache[e1][S[1][i]*blocksize+j] ^= dataCache[k+1][Sdeal[1][i]*blocksize+j];
    				dataCache[e1][S[1][i]*blocksize+j] ^= factor1[j]; 
    			}
    			for(int h = 0; h < k; h++){
    				if(h!=e1) {
    					int index = getMod(Sdeal[1][i]-h,m);
    					if(index != m - 1){
    						for (int j = 0; j < blocksize; j++) {
    							dataCache[e1][S[1][i]*blocksize+j] ^= dataCache[h][index*blocksize+j];
    							if (j==3) {
    								System.out.print(dataCache[h][index*blocksize+3]+" ");
    							}
    						}
    					}
    				}
    			}
    		}
        }
    	
    	   /*修复选用E修复的丢失位S[2]*/
//    	    if (j==3) {
//	    	     System.out.println(dataCache[k+2][Sdeal[2][i]*blocksize+j]);
//	    	     //System.out.println((-53)^94^(-60)^(65)^(-80)^(68));
//	        }
     	   for(int i=0;i<S[2].length;i++) {
     			for (int j = 0; j < blocksize; j++){
     				dataCache[e1][S[2][i]*blocksize+j] ^= dataCache[k+2][Sdeal[2][i]*blocksize+j];
     				dataCache[e1][S[2][i]*blocksize+j] ^= factor2[j]; 
     			}
     			for(int h = 0; h < k; h++){
     				if(h!=e1) {
     					int index = getMod(Sdeal[2][i]-2*h,m);
     					if(index != m - 1){
     						for (int j = 0; j < blocksize; j++) {
     							dataCache[e1][S[2][i]*blocksize+j] ^= dataCache[h][index*blocksize+j];
     						    
     						}
     					}
     				}
     			}
     		}
     	   
     	  /*修复选用F修复的丢失位S[3]*/
        	for(int i=0;i<S[3].length;i++) {
        		if(Sdeal[3][i]==3*e1-1) {
        			for (int h = 1; h < k; h++) {
        				if(h!=e1) {
        					for (int j = 0; j < blocksize; j++) {
        						dataCache[e1][S[3][i]*blocksize+j]^=factor3[j];  //p-1-i 斜率为1
        						dataCache[e1][S[3][i]*blocksize+j]^= dataCache[h][getMod(m-1-3*h,m)*blocksize+j];
        					}
        				}
        	        }
        		}else{
        			for (int j = 0; j < blocksize; j++){
        				dataCache[e1][S[3][i]*blocksize+j] ^= dataCache[k+3][Sdeal[3][i]*blocksize+j];
        				dataCache[e1][S[3][i]*blocksize+j] ^= factor3[j]; 
        			}
        			for(int h = 0; h < k; h++){
        				if(h!=e1) {
        					int index = getMod(Sdeal[3][i]-3*h,m);
        					if(index != m - 1){
        						for (int j = 0; j < blocksize; j++) {
        							dataCache[e1][S[3][i]*blocksize+j] ^= dataCache[h][index*blocksize+j];
        						}
        					}
        				}
        			}
        		}
            } 
        int count_R=0;	
        for(int i=0;i<m-1;i++) {
        	for(int j=0;j<k;j++) {
        		if ((getMod(i+j,m)!=m-1) && (getMod(i+2*j,m)!=m-1) && (getMod(i+3*j,m)!=m-1) && notmember((byte)getMod(i+3*j,m),Sdeal[3]) && notmember((byte)getMod(i+2*j,m),Sdeal[2]) && notmember((byte)getMod(i+j,m),Sdeal[1]) && notmember((byte)i,Sdeal[0]))
        		{
        			count_R++;
        		}
        	}
        }
        int download=(m-1)*m-count_R;
        download=download*blocksize/1024;
    	return download;
    }
 
   public int repair_3(byte[][] dataCache, int shardsize, int blocksize, int e1, byte[][] Sdeal,byte[][] S){
	   /*先修复用R修复的失效位*/
	   for(int i=0;i<Sdeal[0].length;i++) {
	 		for (int j = 0; j < blocksize; j++) {
	 	        for(int h=0;h<k+1;h++) {
	 	           if(h!=e1)
	 		       dataCache[e1][Sdeal[0][i]*blocksize+j] ^= dataCache[h][Sdeal[0][i]*blocksize+j];
	 	        } 
	 	    }	
	 	}
	 	
	   /*确认公共元素 斜率为1 2的公共因子  factor1 factor2*/
	 	byte[] factor1= new byte[blocksize];
	 	byte[] factor2= new byte[blocksize];
	 	Object[] O1= {false,0};
	   //p-1-e1一定在S_0中   ; p-1-2*e1可能在S_0中，不然在S_2中 ; 
	   //如果失效列是第0列，即失效位不包含公共元素，可以直接求公共部分
	 	if(e1==0) {                                     
	 		for (int i = 1; i < k; i++) {
	             for (int j = 0; j < blocksize; j++) {
	                 factor1[j] ^= dataCache[i][getMod(m-1-i,m)*blocksize+j];    //p-1-i 斜率为1
	             }
	         }
	         for (int i = 1; i < k; i++) {
	             for (int j = 0; j < blocksize; j++) {
	                 factor2[j] ^= dataCache[i][getMod(m-1-2*i,m)*blocksize+j];  //p-1+2*i 斜率为2
	             }
	         }
	 	} 
	 	//p-1-e1一定在S_0中   ; p-1-2*e1可能在S_0中，不然在S_2中 ; 
	 	else{
	 		/*factor1*/
	 		for (int i = 1; i < k; i++) {
	             for (int j = 0; j < blocksize; j++) {
	                 factor1[j] ^= dataCache[i][getMod(m-1-i,m)*blocksize+j];  //p-1+2*i 斜率为2
	             }
	         }
	 		/*factor2*/
	 		O1=ismember((byte)getMod(m-1-2*e1,m),S[1]);
	 		if((Boolean) O1[0]) {
	 		   for (int i = 1; i < k; i++){
	                 for (int j = 0; j < blocksize; j++) {
	                     factor2[j] ^= dataCache[i][getMod(m-1-2*i,m)*blocksize+j];  //p-1+2*i 斜率为2
	                 }
	           }
	    	}
	 		else{                            //p-1-2*e1在S_2(2*e1-1在Sdeal中)，求公共位  
	    	    	//2*e1-1  先异或上斜率为2的检验位
	    	    for (int j = 0; j < blocksize; j++) {
	                factor2[j] ^= dataCache[k+2][getMod(2*e1-1,m)*blocksize+j];  
	            }
	    	    	//2*e1-1  对应斜率为2的信息位
	    	        for(int h = 0; h < k; h++){
	    	           int index = getMod(2*e1-1-2*h,m);
	    	           if(index != m - 1){
	    	              for (int j = 0; j < blocksize; j++) {
	    	                  factor2[j] ^= dataCache[h][index*blocksize+j];	
	    	              }
	    	           }
	    	        }
	    	    }		
	 	}
	 	
	   /*test factor*/
	   //for(int L=0;L<15;L++) 
	   //   System.out.print(factor1[L]+" ");
	 	
	    /*修复选用E修复的丢失位S[1]*/
	 	for(int i=0;i<S[1].length;i++) {
	 		for (int j = 0; j < blocksize; j++){
	 			dataCache[e1][S[1][i]*blocksize+j] ^= dataCache[k+1][Sdeal[1][i]*blocksize+j];
	 			dataCache[e1][S[1][i]*blocksize+j] ^= factor1[j]; 
	 		}
	 		for(int h = 0; h < k; h++){
 				if(h!=e1) {
 					int index = getMod(Sdeal[1][i]-h,m);
 					if(index != m - 1){
 						for (int j = 0; j < blocksize; j++) {
 							dataCache[e1][S[1][i]*blocksize+j] ^= dataCache[h][index*blocksize+j];
// 							if (j==3) {
// 								System.out.print(dataCache[h][index*blocksize+3]+" ");
// 							}
 						}
 					}
 				}
 			}   
	 	}
	 	
	   /*修复选用E修复的丢失位S[2]*/
	 	for(int i=0;i<S[2].length;i++) {
	  	   if(Sdeal[2][i]==2*e1-1) {
	  		 for (int h = 1; h < k; h++) {
	 				if(h!=e1) {
	 					for (int j = 0; j < blocksize; j++) {
	 						dataCache[e1][S[2][i]*blocksize+j]^=factor2[j];  //p-1-i 斜率为1
	 						dataCache[e1][S[2][i]*blocksize+j]^= dataCache[h][getMod(m-1-2*h,m)*blocksize+j];
	 					}
	 				}
	 	      }	
	  	  }
		  else{
	  			for (int j = 0; j < blocksize; j++){
	  				dataCache[e1][S[2][i]*blocksize+j] ^= dataCache[k+2][Sdeal[2][i]*blocksize+j];
	  				dataCache[e1][S[2][i]*blocksize+j] ^= factor2[j]; 
	  			}
	  			for(int h = 0; h < k; h++){
	  				if(h!=e1) {
	  					int index = getMod(Sdeal[2][i]-2*h,m);
	  					if(index != m - 1){
	  						for (int j = 0; j < blocksize; j++) {
	  							dataCache[e1][S[2][i]*blocksize+j] ^= dataCache[h][index*blocksize+j];
	  						    
	  						}
	  					}
	  				}
	  			}
	  	   } 
	 	}
	  	   
	 	int count_R=0;	
	     for(int i=0;i<m-1;i++) {
	     	for(int j=0;j<k;j++) {
	     		if ((getMod(i+j,m)!=m-1) && (getMod(i+2*j,m)!=m-1) && notmember((byte)getMod(i+2*j,m),Sdeal[2]) && notmember((byte)getMod(i+j,m),Sdeal[1]) && notmember((byte)i,Sdeal[0]))
	     		{
	     			count_R++;
	     		}
	     	}
	     }
	     int download=(m-1)*m-count_R;
	     download=download*blocksize/1024; 
	 	 return download;
	 }
}
