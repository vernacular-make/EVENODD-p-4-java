/**
 * @author Administrator
 * @date 2019/12/30 0030 19:30
 */
package rto3;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.security.MessageDigest;

/**
 * Command-line program that decodes a file using Reed-Solomon 4+2.
 *
 * The file name given should be the name of the file to decode, say
 * "foo.txt".  This program will expected to find "foo.txt.0" through
 * "foo.txt.5", with at most two missing.  It will then write
 * "foo.txt.decoded".
 */
public class Decode {
    /**	对于阵列码需要添加参数p*/
    public static final int m = Protocol.m;
    public static final int k = Protocol.k;
    public static final int DATA_NODES = k;
    public static final int TOTAL_NODES = k+3;
    public static final int BYTES_IN_INT = 4;

    @SuppressWarnings("ResultOfMethodCallIgnored")
    public static void main(String [] arguments) throws IOException {

        // Parse the command line
//        if (arguments.length != 1) {
//            System.out.println("Usage: SampleDecoder <fileName>");
//            return;
//        }
//        final File originalFile = new File(arguments[0]);
//        long startTime = System.currentTimeMillis();

        for (int t = 0; t < k; t++) {
            for (int y = t+1; y < k; y++) {
                int e1 = t;
                int e2 = y;

                String filePath = "D:\\JAVAworkspace\\1.mp4";
                final File originalFile = new File(filePath);
                if (!originalFile.exists()) {
                    System.out.println("Cannot read input file: " + originalFile);
                    return;
                }

                // Read in any of the shards that are present.
                // (There should be checking here to make sure the input
                // shards are the same size, but there isn't.)
                final byte [] [] shards = new byte [TOTAL_NODES] [];
                final boolean [] shardPresent = new boolean [TOTAL_NODES];
                int shardSize = 0;
                int shardCount = 0;
                int blocksize = 0;
                for (int i = 0; i < TOTAL_NODES; i++) {
                    if(i == e1 || i == e2){
                        System.out.println("error = " + i);
                        continue;
                    }
                    File shardFile = new File(
                            originalFile.getParentFile(),
                            originalFile.getName() + "." + i);
                    if (shardFile.exists()) {
                        shardSize = (int) shardFile.length();
//               System.out.println("shardSize = " + shardSize);
                        blocksize = shardSize / (m - 1);
                        shards[i] = new byte [shardSize];
//                System.out.println("shardSize : " + shardSize);
                        shardPresent[i] = true;
                        shardCount += 1;
                        InputStream in = new FileInputStream(shardFile);
                        in.read(shards[i], 0, shardSize);
                        in.close();
//                System.out.println("Read " + shardFile);
                    }
                }

                // We need at least DATA_NODES to be able to reconstruct the file.
                if (shardCount < DATA_NODES) {
                    System.out.println("Not enough shards present");
                    return;
                }

                // Make empty buffers for the missing shards.
                for (int i = 0; i < TOTAL_NODES; i++) {
                    if (!shardPresent[i]) {
                        shards[i] = new byte [shardSize];
                    }
                }

                // Use EVENODD+ to fill in the missing shards
                byte[] f1 = new byte[blocksize];

                evenodd eo = evenodd.create();
                eo.decodeMissing(f1, shards, shardPresent, shardSize, blocksize);

                // Combine the data shards into one buffer for convenience.
                // (This is not efficient, but it is convenient.)
                byte [] allBytes = new byte [shardSize*DATA_NODES];
                for (int i = 0; i < DATA_NODES; i++) {
                    System.arraycopy(shards[i], 0, allBytes, shardSize * i, shardSize);
                }
//        System.out.println("allByte size = " + allBytes.length);
                // Extract the file length
                int fileSize = ByteBuffer.wrap(allBytes).getInt();
//        System.out.println("file size = " + fileSize);

                // Write the decoded file
                File decodedFile = new File(originalFile.getParentFile(), originalFile.getName() + ".decoded");
                OutputStream out = new FileOutputStream(decodedFile);
                out.write(allBytes, BYTES_IN_INT, fileSize);
                System.out.println("Wrote " + decodedFile);

                File outputFile = new File(
                        originalFile.getParentFile(),
                        originalFile.getName() + "." + 222);
                OutputStream out2 = new FileOutputStream(outputFile);
                out2.write(f1);
                out2.close();


                // 读取原始文件
                String path1 = "D:\\JAVAworkspace\\1.mp4";
                String path2 = "D:\\JAVAworkspace\\1.mp4.decoded";

                String hash_path1 = null;
                String hash_path2 = null;
                try {
                    hash_path1 = getHash(path1, "MD5");
                    hash_path2 = getHash(path2, "MD5");
                } catch (Exception e) {
                    e.printStackTrace();
                }
//        System.out.println("path1 md5:" + hash_path1);
//        System.out.println("path2 md5:" + hash_path2);
                if (hash_path1.endsWith(hash_path2)) {
                    System.out.println("文件相同");
                } else {
                    System.out.println("error = " + e1 + "   " + " e2");
                    System.out.println("文件不相同");
                }


            }
        }
        
//        String filePath = "F:\\test\\text\\1.jpg";
//        final File originalFile = new File(filePath);
//
//        if (!originalFile.exists()) {
//            System.out.println("Cannot read input file: " + originalFile);
//            return;
//        }
//
//        // Read in any of the shards that are present.
//        // (There should be checking here to make sure the input
//        // shards are the same size, but there isn't.)
//        final byte [] [] shards = new byte [TOTAL_NODES] [];
//        final boolean [] shardPresent = new boolean [TOTAL_NODES];
//        int shardSize = 0;
//        int shardCount = 0;
//        int blocksize = 0;
//        for (int i = 0; i < TOTAL_NODES; i++) {
//            if(i == 2 || i == 5){
//                continue;
//            }
//            File shardFile = new File(
//                    originalFile.getParentFile(),
//                    originalFile.getName() + "." + i);
//            if (shardFile.exists()) {
//                shardSize = (int) shardFile.length();
////                System.out.println("shardSize = " + shardSize);
//                blocksize = shardSize / (m - 1);
//                shards[i] = new byte [shardSize];
////                System.out.println("shardSize : " + shardSize);
//                shardPresent[i] = true;
//                shardCount += 1;
//                InputStream in = new FileInputStream(shardFile);
//                in.read(shards[i], 0, shardSize);
//                in.close();
////                System.out.println("Read " + shardFile);
//            }else{
//                System.out.println("error = " + i);
//            }
//        }
//
//        // We need at least DATA_NODES to be able to reconstruct the file.
//        if (shardCount < DATA_NODES) {
//            System.out.println("Not enough shards present");
//            return;
//        }
//
//        // Make empty buffers for the missing shards.
//        for (int i = 0; i < TOTAL_NODES; i++) {
//            if (!shardPresent[i]) {
//                shards[i] = new byte [shardSize];
//            }
//        }
//
//        // Use Reed-Solomon to fill in the missing shards
////        ReedSolomon reedSolomon = ReedSolomon.create(DATA_NODES, PARITY_SHARDS);
////        reedSolomon.decodeMissing(shards, shardPresent, 0, shardSize);
//
//        byte[] f1 = new byte[blocksize];
//
//          evenodd eo = evenodd.create();
//          eo.decodeMissing(f1, shards, shardPresent, shardSize, blocksize);
//
//        // Combine the data shards into one buffer for convenience.
//        // (This is not efficient, but it is convenient.)
//        byte [] allBytes = new byte [shardSize*DATA_NODES];
//        for (int i = 0; i < DATA_NODES; i++) {
//            System.arraycopy(shards[i], 0, allBytes, shardSize * i, shardSize);
//        }
////        System.out.println("allByte size = " + allBytes.length);
//        // Extract the file length
//        int fileSize = ByteBuffer.wrap(allBytes).getInt();
////        System.out.println("file size = " + fileSize);
//
//        // Write the decoded file
//        File decodedFile = new File(originalFile.getParentFile(), originalFile.getName() + ".decoded");
//        OutputStream out = new FileOutputStream(decodedFile);
//        out.write(allBytes, BYTES_IN_INT, fileSize);
//        System.out.println("Wrote " + decodedFile);
//
//        File outputFile = new File(
//                originalFile.getParentFile(),
//                originalFile.getName() + "." + 222);
//        OutputStream out2 = new FileOutputStream(outputFile);
//        out2.write(f1);
//        out2.close();
//
//
//        // 读取原始文件
//        String path1 = "F:\\test\\text\\1.jpg";
//        String path2 = "F:\\test\\text\\1.jpg.decoded";
//
//        String hash_path1 = null;
//        String hash_path2 = null;
//        try {
//            hash_path1 = getHash(path1, "MD5");
//            hash_path2 = getHash(path2, "MD5");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
////        System.out.println("path1 md5:" + hash_path1);
////        System.out.println("path2 md5:" + hash_path2);
//        if (hash_path1.endsWith(hash_path2)) {
//            System.out.println("文件相同");
//        } else {
//            System.out.println("文件不相同");
//        }

//        long endTime = System.currentTimeMillis();
//        System.out.println("Hcode解码时间：" + (endTime - startTime) + "ms");
    }


    /**
     * 获得文件md5值
     */
    public static String getHash(String fileName, String hashType)
            throws Exception {
        InputStream fis;
        fis = new FileInputStream(fileName);
        byte[] buffer = new byte[1024];
        MessageDigest md5 = MessageDigest.getInstance(hashType);
        int numRead = 0;
        while ((numRead = fis.read(buffer)) > 0) {
            md5.update(buffer, 0, numRead);
        }
        fis.close();
        return toHexString(md5.digest());
    }

    /**
     * md5转成字符串
     */
    public static String toHexString(byte[] b) {
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (int i = 0; i < b.length; i++) {
            sb.append(hexChar[(b[i] & 0xf0) >>> 4]);
            sb.append(hexChar[b[i] & 0x0f]);
        }
        return sb.toString();
    }

    public static char[] hexChar = { '0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };


}
