package rto3;

import static rto3.Protocol.*;

import java.io.IOException;
import java.util.*;

public class test1 {
	/*public static void main(String[] args){
		byte[] stripe1=new byte[14];
		stripe1[0]=-1;
		stripe1[1]=-116;stripe1[2]=63;
		stripe1[3]=-45;stripe1[4]=17;
		stripe1[5]=50;stripe1[6]=-78;
		stripe1[7]=94;stripe1[8]=6;
		stripe1[9]=-48;
		stripe1[10]=0;
		stripe1[11]=0;stripe1[12]=0;
		stripe1[13]=0;
		
		Evenodd F1 = new Evenodd(); 
		F1.MDS(stripe1);
		System.out.println("一条带编码数据：");
		for(int i=0;i<stripe1.length;i++)
		{
				System.out.print(stripe1[i]+" ");
			}
		}
		byte[] stripe1=new byte[14];
		stripe1[0]=-1;
		stripe1[1]=-116;stripe1[2]=63;
		stripe1[3]=-45;stripe1[4]=17;
		stripe1[5]=50;stripe1[6]=-78;
		stripe1[7]=94;stripe1[8]=6;
		stripe1[9]=Galois.divide((byte)10, (byte)5);
		
		Evenodd F1=new Evenodd();
		byte[][] mark0=new byte[14][1];
		byte[] put=new byte[2];
		byte[] put1=new byte[2];
		   byte[][] mark=new byte[7][2];
		   for(int i=0;i<14;i++)
			   {mark0[i][0]=(byte)i;}
		  mark0[5][0]=1;
		  mark0[7][0]=11;
		   mark=F1.inverData(mark0,8,1,1);
		   put=F1.compute(mark[0][1], mark[5][1], mark[2][0]);
		   mark[0][1]= put[0];
		   mark[5][1]= put[1];
		   
		   put=F1.compute(mark[2][1], mark[3][1], mark[2][0]);
		   //mark[2][1]= put[0];
		   //mark[3][1]= put[1];
		   
		stripe1[10]=0;
		stripe1[11]=0;stripe1[12]=0;
		stripe1[13]=0;
		F1.display(mark);
		
		int count1=0;
		int count=0;		
		byte[][] mark=new byte[6][4];
		for(int i=0;i<8;i++){
	    	  //0246 1357
	          if(i%2==0){
	        	  mark[0][count]=(byte)i;
	        	  count++;
	        	  }
	          else{
	              mark[1][count1]=(byte)i;
	              count1++;
	          }
	          
		 }
		
		count1=0;
		count=0;
		for(int i=0;i<8;i++){
	    	  //0145 2367
			 if(i/2==0 || i/2==2){
	        	  mark[2][count]=(byte)i;
	        	  count++;
	        	  }
	          else{
	              mark[3][count1]=(byte)i;
	              count1++;
	          }
	          
		 }
		
		count1=0;
		count=0;
		for(int i=0;i<8;i++){
	    	  //0123 4567
			if(i/4==0){
	        	  mark[4][count]=(byte)i;
	        	  count++;
	        	  }
	        else{
	              mark[5][count1]=(byte)i;
	              count1++;
	          }  
		 }
	       Evenodd F1=new Evenodd();
	       F1.display(mark);
}*/
	private static final Object Byte = null;

	public static void main(String[] args) throws IOException {
		/*
		int c,d,e=0;
		c=1929684 % 11;
		d=1929684 % 10;
		e=1929684 % 6;
		System.out.println(d);
		System.out.println(e);
		System.out.println(!(c==0) && !(d==0));
		
		int k=5;
		int r=4;
		byte[][] data= {                  //nodesize:8  blocksize:2
				{0,127,-123,92,98,0,0,0,0},
				{0,1,0,1,1,0,0,0,0},
				{1,0,1,1,0,0,0,0,0},
				{0,1,0,0,1,0,0,0,0},
				{0,0,1,1,0,0,0,0,0},
				{1,1,0,1,1,0,0,0,0},
				{1,1,0,0,1,0,0,0,0},
				{1,1,0,1,0,0,0,0,0},
		};
		Evenodd3func F1=new Evenodd3func();
		System.out.println("data");
		F1.display(data);
		
		int m = data.length;//列
        int l = data[0].length;//行
        byte[][] temp = new byte[l][m];
        F1.transposed(temp, data);
        //F1.display(temp);
        	
		
        byte[] f1 = new byte[2];
        byte[] f2 = new byte[2];
        byte[] f3 = new byte[2];
      
        evenodd eo = evenodd.create();
        eo.encodeParity1(f1,f2,f3, temp, 8, 2);
        //F1.display(temp);
        int m1 = temp.length;//列
        int l1 = temp[0].length;//行
        byte[][] data_T = new byte[l1][m1];
        F1.transposed(data_T, temp);
        F1.display(data_T);
        
        //有一列失效
        byte[][] dataT_e=new byte[l1][m1];
		byte[][] aa= {{4},{1},{2,3}};
		System.out.println(aa[0].length);
        for (int i=0;i<aa[0].length;i++) {
    	 }
    	 */
		
		/*
        Object[] O1= {true,9};
    	Object[] O2= {false,0};
        System.out.print(O1[0]);
        
        Set<Byte> sets=new HashSet(); 
        sets.add((byte)1);
        sets.add((byte)1);
        sets.add((byte)5);
        sets.add((byte)3);
        for (Byte byte1 : sets) {
			System.out.println(byte1);
		}*/
		
		HashSet<Integer> U=new HashSet<>();
		HashSet<Integer> U_1=new HashSet<>();
    	for(int i=0;i<m-1;i++) {
    		U.add(i);
    	}
    	U_1.addAll(U);
        U.stream().forEach(System.out::println);
        HashSet<Integer> S0=new HashSet<>();
        S0.add(1);
        S0.add(3);
        HashSet<Integer> S1=new HashSet<>();
        S1.add(5);
        S1.add(6);
        
        Evenodd3func f1= new Evenodd3func();
        for (Integer i_0 : S0) {
			for (Integer i_1 : S1) {
				Integer i_2=f1.getMod(i_0, i_1);
				System.out.println("========="+i_2);
			}
		}
        
        U.removeAll(S0);
        U.removeAll(S1);
        Optional<Integer> optional=U.stream().min(new Comparator<Integer>(){
        	@Override
        	public int compare(Integer o1,Integer o2) {
        		return o1-o2;
        	}
        });
        Integer i_1 = optional.get();
        System.out.println("========="+i_1);
        System.out.println("clear after");
        U.stream().forEach(System.out::println);
        U.clear();
        U.addAll(U_1);
        System.out.println("repair");
        //U.stream().forEach(System.out::println);
        System.out.println (Math.floor((m-1)/3));
        
        Byte a=10;
        byte b=11;
        b=a;
        System.out.println ("+++++++"+b);
       
        Integer LS=(int) Math.floor((m-1)/3);
    	Integer HS=(int) Math.floor((m-1)/3)+1;
    	 
        byte[][] S =new byte[3][];
        S[0]=new byte[LS];
        S[1]=new byte[LS];
        S[2]=new byte[HS];
        
        byte[][] Sdeal =new byte[3][];
        Sdeal[0]=new byte[LS];
        Sdeal[1]=new byte[LS];
        Sdeal[2]=new byte[HS];
        
        f1.Spart_3(S);
        
        for(int i=0;i<S.length;i++) {
        	for(int j=0;j<S[i].length;j++) {
        		System.out.print(S[i][j]+" ");
        	}
        	System.out.println();
        }
        for(int i=0;i<Sdeal.length;i++) {
        	for(int j=0;j<Sdeal[i].length;j++) {
        		System.out.print(Sdeal[i][j]+" ");
        	}
        	System.out.println();
        }
        
        
        
	 }
	
	public static void remove_3(TreeSet<Integer> U,HashSet<Integer> A, HashSet<Integer> B) {
		U.removeAll(A);
		U.removeAll(B);
	}
	
}
	
